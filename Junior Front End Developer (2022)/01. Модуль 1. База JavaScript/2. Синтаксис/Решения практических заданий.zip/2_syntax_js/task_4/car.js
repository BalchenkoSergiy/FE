const carName = 'Tesla';
let maxCarSpeed = 200;
let carOwner = 'Maxim';

maxCarSpeed = 180;
console.log('У машины изменилась скорость', maxCarSpeed);
carOwner = 'Igor';
console.log('У машины изменился владелец', carOwner);

maxCarSpeed = 170;
console.log('У машины изменилась скорость', maxCarSpeed);
carOwner = 'Timur';
console.log('У машины изменился владелец', carOwner);

maxCarSpeed = 160;
console.log('У машины изменилась скорость', maxCarSpeed);
carOwner = '';
console.log('У машины изменился владелец', carOwner);

alert(carName);
alert(maxCarSpeed);
alert(carOwner);
