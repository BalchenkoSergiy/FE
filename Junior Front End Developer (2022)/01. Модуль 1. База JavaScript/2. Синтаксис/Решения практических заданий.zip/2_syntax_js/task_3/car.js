const carName = 'Tesla';
let maxCarSpeed = 200;
let carOwner = 'Maxim';

alert(carName);
alert(maxCarSpeed);
alert(carOwner);