// JavaScript код с созданием переменных
/*
Автор:
Максим Филанович
*/

const myName = 'Maxim';
const mySurname = 'Filanovich';
let myFavoriteDrink = 'Coca-Cola';
let myFavoriteAnimal = 'Dog';
let myFavoriteProgrammingLanguage = 'JavaScript';

console.log(myName);
console.log(mySurname);
console.log(myFavoriteDrink);
console.log(myFavoriteAnimal);
console.log(myFavoriteProgrammingLanguage);