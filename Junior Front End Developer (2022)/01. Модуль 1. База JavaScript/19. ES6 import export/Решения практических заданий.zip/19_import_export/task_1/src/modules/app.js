export default class App {
    run() {
        document.body.textContent = 'Hello World';
    }
}
