export const Settings = {
    currency: '$',
}