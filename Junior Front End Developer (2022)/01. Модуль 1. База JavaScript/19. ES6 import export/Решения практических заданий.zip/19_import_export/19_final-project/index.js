import './index.css';

import App from './src/modules/app';

const app = new App()
app.run();