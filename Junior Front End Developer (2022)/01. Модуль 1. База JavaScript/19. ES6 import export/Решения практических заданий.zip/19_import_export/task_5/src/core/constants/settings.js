export const Settings = {
    currency: '$',
}
