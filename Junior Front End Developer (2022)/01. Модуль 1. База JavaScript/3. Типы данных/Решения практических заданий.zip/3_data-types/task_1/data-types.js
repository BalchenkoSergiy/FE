const favoriteDrink = 'coffee';
const numberOfCups = 5;
const isColdDrink = true;
const studentsFavoriteDrink = null;
const carOwner = undefined;
const itCompany = {
  name: 'The Best IT Company',
  numberOfDevelopers: 500,
  isProductCompany: true,
};
const id = Symbol('id');
const bigIntNumber2 = 20n;

console.log('favoriteDrink', favoriteDrink, typeof favoriteDrink);
console.log('numberOfCups', numberOfCups, typeof numberOfCups);
console.log('isColdDrink', isColdDrink, typeof isColdDrink);
console.log('studentsFavoriteDrink', studentsFavoriteDrink, typeof studentsFavoriteDrink);
console.log('carOwner', carOwner, typeof carOwner);
console.log('itCompany', itCompany, typeof itCompany);
console.log('id', id, typeof id);
console.log('bigIntNumber2', bigIntNumber2, typeof bigIntNumber2);