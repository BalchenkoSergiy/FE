let age = 20;
let amount = '100';
let isJavaScriptDev = false;

age = '20';
amount = 100;
isJavaScriptDev = null;

alert(age);
alert(amount);
alert(isJavaScriptDev);