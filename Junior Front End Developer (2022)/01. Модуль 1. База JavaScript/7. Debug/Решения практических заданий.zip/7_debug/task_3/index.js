const salaryOfJuniorDeveloper = 500;
 
const numberOfJuniorDevelopers = 3;
debugger;
let taxPercentage = 13;
let totalJuniorDevelopersSalary = 0;
debugger;

for (let i = 0; i < numberOfJuniorDevelopers; i += 1) {
    debugger;
    const salaryWithTax = salaryOfJuniorDeveloper - (salaryOfJuniorDeveloper * taxPercentage / 100);
    totalJuniorDevelopersSalary += salaryWithTax;
}

debugger;
console.log('totalJuniorDevelopersSalary', totalJuniorDevelopersSalary);