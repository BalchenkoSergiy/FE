let userName = prompt('Как вас зовут?');
userName = userName.toUpperCase().trim();

alert(`Вас зовут ${userName}`);
