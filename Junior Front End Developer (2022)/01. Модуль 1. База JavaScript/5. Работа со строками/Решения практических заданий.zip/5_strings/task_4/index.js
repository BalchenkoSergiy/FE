let userName = prompt('Как вас зовут?');
userName = userName.toUpperCase().trim();

let userAge = prompt('Как вас зовут?');
userAge = Number(userAge.trim());

alert(`Вас зовут ${userName} и вам ${userAge} лет`);
