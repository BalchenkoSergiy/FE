alert('Брендан Эйх');
alert('За 10 дней');
alert('JS появился в 1995 году');
alert('JavaScript это не Java');
alert('ECMAScript');
