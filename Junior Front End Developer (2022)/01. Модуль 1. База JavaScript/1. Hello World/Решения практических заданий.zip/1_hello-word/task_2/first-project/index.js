console.log('Запускаем таймер');
alert('5');
alert('4');
alert('3');
alert('2');
alert('1');
alert('0');
console.log('Обратный отсчет закончен');
