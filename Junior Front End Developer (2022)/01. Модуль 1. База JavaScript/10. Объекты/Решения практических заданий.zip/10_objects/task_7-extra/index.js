function getKiller(suspectInfo, deadPeople) {
    let killerName = '';
    Object.entries(suspectInfo).forEach((data) => {
        const suspectPerson = data[0];
        const peopleWereSeen = data[1];
        const isKiller = deadPeople.every((deadName) => peopleWereSeen.includes(deadName));
        if (isKiller) {
            killerName = suspectPerson;
        }
    })
    
    return killerName;
}
