const MemoWithUseCallbackExample = (props) => {
    return null;
};

export default MemoWithUseCallbackExample;
