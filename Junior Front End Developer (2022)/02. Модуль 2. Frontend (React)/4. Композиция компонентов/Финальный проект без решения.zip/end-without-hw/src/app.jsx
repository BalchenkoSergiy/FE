import React from "react";
import CountersList from "./components/countersList";

const App = () => {
    return <CountersList />;
};
export default App;
