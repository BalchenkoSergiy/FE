export const taskUpdated = "task/updated";
export const taskDeleted = "task/deleted";
