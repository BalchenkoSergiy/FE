export const taskUpdated = "task/updated";
