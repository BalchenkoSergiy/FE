import React from "react";
const DataRelationship = () => {
    return <h1>DataRelationship</h1>;
};

export default DataRelationship;
