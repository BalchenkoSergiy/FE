import React from "react";
const DataStructures = () => {
    return <h1>DataStructures</h1>;
};

export default DataStructures;
