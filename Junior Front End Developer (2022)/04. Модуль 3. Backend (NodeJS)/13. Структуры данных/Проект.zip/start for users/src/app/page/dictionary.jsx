import React from "react";
const DictionaryPage = () => {
    return <h1>DictionaryPage</h1>;
};

export default DictionaryPage;
