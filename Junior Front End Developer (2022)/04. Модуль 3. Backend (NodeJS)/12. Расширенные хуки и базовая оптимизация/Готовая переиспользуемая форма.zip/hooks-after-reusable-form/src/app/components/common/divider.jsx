import React from "react";
const Divider = () => {
    return <hr />;
};

export default Divider;
