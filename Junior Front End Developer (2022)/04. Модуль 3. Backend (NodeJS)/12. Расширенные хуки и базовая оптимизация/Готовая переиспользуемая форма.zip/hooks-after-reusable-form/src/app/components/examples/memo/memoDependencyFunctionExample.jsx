const MemoDependencyFunctionExample = (props) => {
    return null;
};

export default MemoDependencyFunctionExample;
