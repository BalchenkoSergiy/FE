import FormComponent from "./form";

export * from "./fields";
export default FormComponent;
